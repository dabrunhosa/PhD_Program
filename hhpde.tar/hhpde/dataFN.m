%physiological data

a=1/10;
b=5;
c=0.0;
tau=100;

w=zeros(tmax,N);
w(1,:)=1.386;

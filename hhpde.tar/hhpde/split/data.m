%physiological data
eps=1/2^10;
CM=1;  

%discretization data
L=1;
Tfinal=2^5;
N=2^8+1;               % # of spacial nodes
tmax=round((2^14)*sqrt(eps));   % # of time steps. Note the dependance 
                         % on sqrt(eps)
dt=Tfinal/tmax
%dt=0.1;
x=0:L/(N-1):L;
t=0:dt:Tfinal;

%PDE data
Iext=zeros(tmax+1,N); % external current
Iext=0*ones(tmax+1,N);
I0=-(2/eps)*heaviside(100-t);
IN=0*(1/eps)*heaviside(5-t);
%plot(t,I0);
%figure;
%plot(t,IN);
%figure; 

v=zeros(tmax+1,N);
v(1,:)=0*cos(10*(0:2*pi/(N-1):2*pi));
%v(1,:)=100*heaviside(0.21-x)-8*heaviside(x-0.21);
%v(1,:)=-50;


sigma=0; % randonnes of ionic chanels



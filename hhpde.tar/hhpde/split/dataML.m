%physiological data
%C=1;  
%gk=40;
gk=36;
%gna=90;
gna=120;
gl=0.3*ones(1,N);        

%model data (Ermentrout page 51)

%homoclinic
Ek=-84;
ECa=120;
El=-60;
gK=8;
gCa=4;
gL=2;
CM=20;
phi=0.23;
V_1=-1.2;
V_2=18;
V_3=12;
V_4=17.4;

%Hopf bifurcation
Ek=-84;
ECa=120;
El=-60;
gK=8;
gCa=4.4;
gL=2;
CM=20;
phi=0.04;
V_1=-1.2;
V_2=18;
V_3=2;
V_4=30;

n=zeros(tmax,N);
n(1,:)=0.4;
%For the HH model, writen in the form
%-dV/dt+eps*d²V/dx²+Cond(t)*V=I_ext(t)+RHS(t)
%
%it follows that 
%       cond=-g_k*n^4-G_Na*m^3*h-g_L
%       RHS=-g_k*n^4*E_k-G_Na*m^3*h*E_Na-g_L*E_L
%

P=resphh(v(t,:),m(t,:),n(t,:),h(t,:));
m(t+1,:)=m(t,:)+dt*P(1,:)+sigma*sqrt(dt)*randn(1,N);
n(t+1,:)=n(t,:)+dt*P(2,:)+sigma*sqrt(dt)*randn(1,N); 
h(t+1,:)=h(t,:)+dt*P(3,:)+sigma*sqrt(dt)*randn(1,N);

% plot(h(t+1,:));axis([0 N 0 1]);
g=[gk.*power(n(t+1,:),4); gna.*power(m(t+1,:),3).*h(t+1,:); gl]; 
%    g=[gk.*power(n(t,:),4); gna.*power(m(t,:),3).*h(t,:); gl]; 
%    g=[gk.*power((n(t+1,:)+n(t,:))/2,4); gna.*power((m(t+1,:)+m(t,:))/2,3).*(h(t+1,:)+h(t,:))/2; gl]; 

vaux=v(t,:)+dt*( gk.*power(n(t,:),4).*(Ek-v(t,:))...
    +gna.*power(m(t,:),3).*h(t,:).*(Ena-v(t,:))...
    +gl.*(El-v(t,:)) )+dt*Iext(t,:);

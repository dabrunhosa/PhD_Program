function yp = resphh(V,m,n,h)
%  Neurotic HH model.


alphan=0.01.*(10-V)./(exp( (10-V)/10 ) -1 ); 
betan=0.125.*exp(-V/80); 
alpham=0.1.*(25-V)./(exp( (25-V)/10 ) -1 ); 
betam=4.*exp(-V/18); 
alphah=0.07.*exp(-V/20);
betah=1./(exp( (30-V)/10 )+1); 

mrhs=alpham.*(1-m)-betam.*m; % correspondente a "n"
nrhs=alphan.*(1-n)-betan.*n; % correspondente a "m"
hrhs=alphah.*(1-h)-betah.*h; % correspondente a "h"

yp = [mrhs ; nrhs ;hrhs];

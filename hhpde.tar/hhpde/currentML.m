%For the ML model, writen in the form
%-dV/dt+eps*d²V/dx²+Cond(t)*V=I_ext(t)+RHS(t)
%
%it follows that 
%       cond=-g_k*n^4-G_Na*m^3*h-g_L
%       RHS=-g_k*n^4*E_k-G_Na*m^3*h*E_Na-g_L*E_L
%

n_inf=(1+tanh((v(t,:)-V_3)/V_4))/2;
tau_n=1./(cosh((v(t,:)-V_3)/(2*V_4)));
m_inf=(1+tanh((v(t,:)-V_1)/V_2))/2;
n(t+1,:)=n(t,:)+dt*phi*(n_inf-n(t,:))/tau_n;  
%    g=[gk.*power(n(t,:),4); gna.*power(m(t,:),3).*h(t,:); gl]; 
%    g=[gk.*power((n(t+1,:)+n(t,:))/2,4); gna.*power((m(t+1,:)+m(t,:))/2,3).*(h(t+1,:)+h(t,:))/2; gl]; 

condut=-gK*n(t+1,:)-gCa*m_inf-gL;
RHS=-gK*n(t+1,:)*Ek-gCa*m_inf*ECa-gL*El;

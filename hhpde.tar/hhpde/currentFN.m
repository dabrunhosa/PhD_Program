%For the FN model, writen in the form
%-dV/dt+eps*d²V/dx²+Condut(t)*V=I_ext(t)+RHS(t)
%
%it follows that 
%       condut=1-v^2/3
%       RHS=w
%

w(t+1,:)=w(t,:)+(dt/tau)*(a*v(t,:)+c-b*w(t,:));  

condut=1-(v(t,:).^2)/3;
condut=(v(t,:)-a).*(1-v(t,:));
RHS=w(t+1);
function sol = odebc(alpha,beta,f,I0,IN,L,N)
%  solve the ODE alpha u''+beta u= f in (0,L), with Neumann boundary 
%  conditions I0, IN at the end points.  
%  alpha is a scalar, but beta is a vector, since it depends on x
% 
%  It uses central finite difference
%  scheme with N nodes. 
%  Data: alpha, L, I0, IN, alpha: constants and f, beta: N dimensional
%  vector. 

h=L/(N-1);
A=toeplitz([-2*alpha/h^2 alpha/h^2 zeros(1,N-2)]);
A(1,:)=[-2*alpha/h^2 2*alpha/h^2 zeros(1,N-2)];
A(N,:)=[zeros(1,N-2) 2*alpha/h^2 -2*alpha/h^2];
A=A+diag(beta);
rhs=f+(2*alpha/h)*[I0 zeros(1,N-2) -IN];
sol=A\rhs';


%physiological data
%C=1;  
%gk=40;
gk=36;
%gna=90;
gna=120;
gl=0.3*ones(1,N);        

Ek=-12;
Ena=115;
El=10.6;

%g=ones(1,N);

m=zeros(tmax,N);
m(1,:)=0.1;
n=zeros(tmax,N);
n(1,:)=0.4;
h=zeros(tmax,N);
h(1,:)=0.4;



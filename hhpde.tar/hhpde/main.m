%Solves nerve equations
% The equation is of the form 
%      -C_M*dV/dt+eps*d²V/dx²+Condut(t)*V=I_ext(t)+RHS(t)
% where the "conductance" Cond and the right hand side RHS 
% depends on the model. I_ext is an applied external current
% 
%
%The numerical method:
% *discretize in time first: 
%   -C_M*V_{n+1}+C_M*V_n+eps*dt*d²V_{n+1}/dx²+dt*Condut*V_{n+1}
%                                                      =dt*(RHS+I_ext)
% *solve the above elliptic PDE of the form
%   alpha u''+beta u= f
%
%where alpha=eps*dt
%      beta=-CM+dt*Condut
%      f=dt*(RHS+I_ext)-C_M*V_n
%
clear all; 
data; %read all the data

%choose the model
model='HH';
%model='ML';
%model='FN';

%read the data for each model
switch model
    case 'HH'
        dataHH;
    case 'FN'
        dataFN
    case 'ML'
        dataML;
    otherwise
        disp('Unknown model.')
end

aviobj = avifile('example.avi');
plot(v(1,:));
M(1)=getframe(gcf);
aviobj = addframe(aviobj,M(1));
x=0:L/(N-1):L;
sigma=0.0; % amount of noise added

for t=1:tmax
    switch model
          case 'HH'
            currentHH;
          case 'FN'
            currentFN;
          case 'ML'
            currentML;
          otherwise
            disp('Unknown model.')
    end
    v(t+1,:)=odebc(dt*eps,-CM+dt*condut,-CM*v(t,:)+dt*RHS+dt*Iext(t+1,:),...
         I0(t+1),IN(t+1),L,N); 
%    v(t+1,:)=v(t,:)+dt*(v(t,:).*condut-Iext(t,:)-RHS);
    plot(x,v(t+1,:)); axis([0 1 -15 95]);
    leg=['time=',num2str((t-1)*dt,2)];
    legend(leg);
   
    M(t+1)=getframe(gcf);
    aviobj = addframe(aviobj,M(t+1));
end;
aviobj = close(aviobj);
%figure; 
%surf(v);
%figure;
%surf(m)
%figure; 
%surf(n); 
%figure; 
%surf(h)
%figure;
%movie(M);
